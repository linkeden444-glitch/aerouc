# AERO TUNNEL PRO — ANDROID STUDIO PROJECT (V2)

## Project Overview
This is the complete, production-ready Android Studio project for **Aero Tunnel Pro**.
It encapsulates high-performance WebView runtime integration, native Android intent routing, and VIP activation security.

## Directory Structure
- `app/src/main/java/com/nexus/tunnel/MainActivity.java`: Native Java bridge handling:
  - `openIADBApp()`: Launches IADB Helper (`com.iadb.helper`) with automatic Google Play Store fallback.
  - `openSRFileManager()`: Launches RS File Manager (`com.rs.explorer.filemanager`) with automatic Google Play Store fallback.
  - `showFileManagerChooser()`: Native Android 10 storage framework picker (`ACTION_OPEN_DOCUMENT_TREE`).
  - `toggleVPNService()`: VPN tunnel connection status handler.
  - `saveKey()` / `getSavedKey()` / `deleteKey()`: SharedPreferences encrypted persistent storage.
- `app/src/main/assets/index.html`: Complete standalone web interface (Zero emojis, Orange/White/Black WordPress styling, live timer sync).
- `app/src/main/AndroidManifest.xml`: Configured with Android 11+ `<queries>` for `com.iadb.helper` and `com.rs.explorer.filemanager`, full network permissions, and hardware acceleration.
- `APK_RELEASE/`: Contains the compiled, ready-to-install APK (`AeroTunnel_v2.apk`).

## How to Build
### Via Command Line:
```powershell
.\gradlew.bat assembleDebug
```
The output APK will be generated at:
`app\build\outputs\apk\debug\app-debug.apk`

### Via Android Studio:
1. Open Android Studio.
2. Select **Open** and choose this `AERO_ANDROID_PROJECT_V2` directory.
3. Allow Gradle sync to complete.
4. Click **Build > Build Bundle(s) / APK(s) > Build APK(s)**.

## Pre-built APK Location
- `AERO_ANDROID_PROJECT_V2/APK_RELEASE/AeroTunnel_v2.apk`
- Also copied to workspace root: `AeroTunnel_v2.apk`

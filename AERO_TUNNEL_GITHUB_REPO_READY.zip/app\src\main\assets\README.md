# AERO TUNNEL PRO — LATEST STANDALONE VERSION (V2)

## Overview
This directory contains the standalone web runtime and frontend assets for **Aero Tunnel Pro** (Version 2).
It is fully optimized for embedding inside Android WebViews as well as direct browser testing.

## Key Features & Specifications
1. **Zero Emojis UI:** Professional, distraction-free interface matching WordPress color palette (White `#FFFFFF`, Vivid Orange `#FF6B00`, Deep Slate/Black `#0F172A`).
2. **Immediate Activation Gate:** Prompts for VIP license key immediately upon launch before unlocking tunnel controls.
3. **Exact Timer Sync:** Connects to `/api/index.php?endpoint=verify_key` to fetch remaining duration in seconds (`remaining_seconds`), with reverse countdown ticker.
4. **Dual Android Routing:**
   - **Android 11+:** Integrated with **IADB Helper** (`com.iadb.helper`) and **RS File Manager** (`com.rs.explorer.filemanager`) with automatic Play Store fallback.
   - **Android 10:** Standard file system storage chooser (`ACTION_OPEN_DOCUMENT_TREE`).
5. **Real-time Terminal Logs:** Live debug log output with one-tap clipboard copy.

## Files
- `index.html`: Main standalone web application.
- `app_preview.html`: Fast desktop preview and testing harness.
- `logo.png` & `icon.png`: Aero official branding assets.
- `favicon.ico`: Web shortcut icon.

## Demo VIP License Key
- Key: `AERO-VIP-2026`
- Duration: 24 Hours (1440 Minutes / 86,400 Seconds)
